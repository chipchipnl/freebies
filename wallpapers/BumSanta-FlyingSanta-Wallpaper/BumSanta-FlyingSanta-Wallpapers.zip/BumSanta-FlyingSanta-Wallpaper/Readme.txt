Get in touch:
Visit our website for more sticker packs and information: https://www.chipchip.nl
Follow us on Twitter: https://www.twitter.com/chipchipNL
Join us at Facebook: https://www.facebook.com/chipchipNL

Copyright ChipChip 2016